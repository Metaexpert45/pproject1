import React from 'react'

import './question1.css'

const Question1 = (props) => {
  return <div className="question1-container"></div>
}

export default Question1
